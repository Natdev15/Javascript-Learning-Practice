// Variables

// var a = "Natu";
// var b = "Kumar";
// console.log(a + " " +b)


// var a = "Natu";
// a = "Natesh";
// var b = " kumar"
// var c = a.concat(b);
// console.log(c)


// var a = "Natu";
// var b = "Kumar";
// a = a.replace("Natu", "Natesh");
// console.log(a + " " + b)


// let namee = "Natesh Kumar";
// let age = 20;
// console.log(`Hello Mr. ${namee}.\nYour are ${age} years-old.`  )
// yeh 2 lines par likhdehga 


// let name = "Natu";
// let age = 20;
// name ="Natesh";
// console.log(`Mr. ${name} kumar. \nYour age is ${20}`)


// const name = "Natu";
// const age = 20;
// console.log(name + "\n"  + age)



// const name = "Natu";
// const age = 20;
// name = "Natesh";
// console.log(name)
// yeh change nhi krega kyunke const 1 baar hi assign hota hai 

// Const 1 baar jo assign hojaye uske baad nhi hoga 
// Or Let bhi 1 baar hota hai par usmei Local or Globally farq hota hai 
// Or Var mei kuch nhi hota jaha chahe assigned value change krsakte hai hum 



// Local & Global Let 
// let a = 6;
// let b = 2;
// function calc() {
//     let a = 4;
//     let b = 2;
//     a = 8;
    // yeh locally Let change ho rha hai 
//     console.log(a + b);
// }
// calc();
// a = 7;
// console.log(a * b)
// yeh globally change ho rha hai 
// a = 5;
// yeh again let ki value ko change kiya 
// console.log(a + b);




// Strings 

// let para = "'Natu' k dost harami hai kiya kare";
// console.log(para)


// let para = "he is good at his level"
// let para1 = "he needs more effeciency to ehance his level"
// console.log(para + "\n" + para1)


// let para = "he is good at his level"
// para = para.concat("\nhe needs more effeciency to ehance his level")
// console.log(para)



// String Functions 

// let namee = "Natesh Kumar";
// namee = namee.toUpperCase();
// console.log(namee)


// let name1 = "N A T U";
// name1 = name1.toLowerCase();
// console.log(name1)


// let name = "Natu Kumar";
// name = name.concat(' is gud boy');
// console.log(name)


// let namee = "Natu Kumar & he is good student";
// namee = namee.split();
// console.log(namee)
// yeh Arrays form mei convert krdehga


// let namee = "       Natu   kumar          ";
// namee = namee.trim();
// console.log(namee)
// it will remove whitespaces from starting and ending 


// let namee = "Natu Kumar \n";
// namee = namee.repeat(4);
// console.log(namee)


// let para = "Natesh kumar why did u not come yesterday?";
// para = para.indexOf("ku")
// console.log(para)
// agay se joh kareeb hoga "ku" uska index number btayega


// let para = "Natesh kumar why did u not come yesterday?";
// para = para.indexOf("e")
// console.log(para)
// agay se joh kareeb hoga "e" uska index number btayega


// let para = "Natesh kumar why did u not come yesterday?";
// console.log(para.length)
// it will show the length of this string 
// para = para.lastIndexOf('a')
// console.log(para)
// last(piche) se joh kareeb hoga "e" uska index number btayega


// let para1 = "Natesh kumar why did u not come yesterday?";
// para1 = para1.substring(0, 12)
// console.log(para1)


// let para1 = "Natesh kumar why did u not come yesterday?";
// para1 = para1.substr(0, 9)
// console.log(para1)


// let para1 = "Natesh kumar why did u not come yesterday?";
// para1 = para1.slice(0, 16)
// console.log(para1)


// let para1 = "Natesh kumar why did u not come yesterday?";
// para1 = para1.charAt(4)
// console.log(para1)
// yeh btayega k 4rth number konsa charater hai 


// let para1 = "Natesh kumar why did u not come yesterday?";
// para1 = para1.charCodeAt(a)
// console.log(para1)
// yeh btayega k is character ka ASCII code kiya hai 




// Arrays 

// let namesList = ["Natesh", "Natu", "Niku", "Nitu"];
// console.log(namesList)


// let namesList = ["Natesh", "Natu", "Niku", "Nitu"];
// namesList = namesList.toString()
// console.log(namesList)
// yeh in arrays ko Strings ki form mei krdehga 


// For Loop
// let namesList = ["Natesh", "Natu", "Niku", "Nitu"];
// for (let index = 0; index < namesList.length; index++) {
//     const element = namesList[index];
//     console.log(element + " ,Welcome in our resort.")
// }


// For Each function 
// let namesList = ["Natesh", "Natu", "Niku", "Nitu"];
// namesList.forEach(element => {
//     console.log(element + ", Warm welcome in coding center")
// });


// let namesList = ["Natesh", "Natu", "Niku", "Nitu"];
// for (const elements of namesList) {
//     console.log(elements + ", Welcome in our Restaurant")
// }


// for of 
let arr212121 = ["Natesh", "Nitu", "Natu", "Nitesh"];
for (let index = 0; index < arr212121.length; index++) {
    const ele21 = arr212121[index];
    console.log(`welcome bhai ${ele21}`)
}


// for EAch 
let arr21212121 = ["Nitu", "Deepu", "Nani", "Munu"];
arr21212121.forEach(ele => {
    console.log(`welcome bhai log ${ele}`)
});


// for of 
let arr2121212121 = ["niku", "nitu", "nitesh", "nateshwar"];
for (const iter of arr2121212121) {
    console.log(`welcome  ${iter} bhai ji `)
}



// for in  
let obj21212121 = {name: "niku", age: 21, address: "H#75", city: "MPK" }
for (const eleKey in obj21212121) {
        console.log(`the ${eleKey} of this object is ${obj21212121[eleKey]}`)
    }


    


// Objects

// let data = {
//     name: "Natesh",
//     age: 20,
//     address: "H#75 Karimabad Town Mirpurkhas",
//     postal: 69000,
// }
// console.log(data)



// let data = {
//     name: "Natesh",
//     age: 20,
//     address: "H#75 Karimabad Town Mirpurkhas",
//     postal: 69000,
// }
// console.log(data.age)
// console.log(data.postal.toString())
// console.log(data.address.toUpperCase())


// For in Loop 
// let data = {
//     name: "Natesh",
//     age: 20,
//     address: "H#75 Karimabad Town Mirpurkhas",
//     postal: 69000,
// }
// for (const key in data) {
//       console.log(`The object of ${key} is ${data[key]} `)
//     }




let obj212121 = {
    name: "Natesh",
    age: 20,
    address: "House No: 75",
    town: "Karimabad",
    city: "Mirpurkhas"
}
for (const key in obj212121) {
        console.log(`The ${key} of this object is ${obj212121[key]}`)
    }




// If condition

// let name = prompt("enter your name?", "enter your name here");
// if (name === "Natesh") {
//     console.log(`welcome Mr. ${name} Kumar`)
// }
// else{
//     console.log('sorry sir u r another person')
// }


// If - Else-If Condition 

// let name = prompt("enter your name?", 'enter here');
// if (name === "Natu") {
//     console.log(`welcome Mr. ${name}`)
// }
// else if(name === "Kanchan"){
//     console.log(`welcome Ms. ${name}. Natu ki behna`)
// }
// else {
//   console.log("wrong")  
// }


// Switch Statement 

// let age = 22;
// switch (age) {
//     case 20:
//         console.log('your age is perfect')
//         break;
//     case 22:
//         console.log('your age is moderate')
//         break;
//     case 12:
//         console.log('your age is too small')
//         break;

//     default:
//         console.log('better luck for next time')
//         break;
// }

// Switch 
// let age = 20;
// switch (age) {
//     case 20:
//         console.log('your age is perfect')
//         break;
//     case 22:
//         console.log('your age is moderate')
//         break;
//     case 12:
//         console.log('your age is too small')
//         break;

//     default:
//         console.log('better luck for next time')
//         break;
// }


// if Statement with prompt
// let age = prompt('enter your age?', 'enter here..')
// if(age < 18){
//     console.log("you are not eligible")
// }
// else if(age == 18 || age < 26){
//     console.log("you are eligible")
// }
// else if(age > 28){
// console.log("you are strickly not eligible")
// }
// else{
//     console.log('Better luck for next time')
// }


// Switch Statement with prompt  
// let age = prompt('enter your age?', 'enter here..')
// switch (age) {
//     case "12":
//         console.log('you arr too young')
//         break;

//     case "18":
//         console.log('you arr perfect')
//         break;

//     case "22":
//         console.log('you arr moderate')
//         break;

//     case "28":
//         console.log('you arr too old')
//         break;

//     default:
//         console.log('Better Luck for next time')
//         break;
// }



// For Loop 

// let i;
// for(i=0; i<5; i++){
//     console.log(i)
// }
// counting 0 to 4 means 5 numbers of counting 


// let i;
// for(i=10; i>0; i--){
//     console.log(i)
// }
// reverse counting 10 to 2


// Multiplication Table in JS through For Loop 

// let num = prompt('enter integer here');
// let i;
// for(i=1; i<=10; i++){
//     result = i*num;
//     console.log(` ${num} * ${i} = ${result}`)
// }


// Another way with the help of Parinteger Func: 
// let num = parseInt(prompt('enter any integer number', 'enter here'))
// for (let i=1; i<=10; i++) {
//     result = i*num;
//     console.log(`${num} * ${i} = ${result}`)
// }


// Another way with limit of Table (means kaha tak chale yeh bhi ask krega)
// let num = parseInt(prompt('enter any of integer', 'enter here ..'));
// let range = parseInt(prompt('enter the range of Table', 'enter here ..'))
// let a;
// for(a=1; a<=range; a++){
//     result = a*num;
//     document.write(`${num} * ${a} = ${result} <br> `)
// }



// Again Rangable Table 
// let no = prompt('enter any inter value')
// let ran = prompt('enter range')
// let showMsg = confirm("do you wanna see the result?")
// if(showMsg == true){
// let b;
// for(b=1; b<=ran; b++){
//     result = b*no;
//     console.log(`${no} * ${b} = ${result}`)
//     }
// }
//     else{
//         console.log("you are not interested")
//     }
// ismei yeh table show krne ka pouchega user se yes or no through Confirm 



// While Loop 

// let i=0;
// while (i<=10) {
//     console.log(i);
//     i++;
// }
// yeh condition phle dekhega phir usko execute krega


// Another example of While Loop 
// let i = 10;
// while (i>0) {
//     console.log(i);
//     i--;
// }
// Reverse counting 


// Another example of While Loop (yeh ruk jayega kyuke condition true nhi hogi) 
// let i = 10;
// while (i<0) {
//     console.log(i);
//     i--;
// }


// same as above in Do While 
// let j = 12;
// do {
//     console.log("yeh Do while hai \n" + j);
//     j--;
// } while (j<0);
// ab yeh condition false hai phir bhi yeh isko 1 baar execute kr raha hai yehi d/f hai while or do while mei 



// Multiplication table in while loop 
// let num = parseInt(prompt('enter any integer number'));
// let i =0
// while (i<=10) {
//     result = i*num;
//     console.log(`${num} * ${i} = ${result}`)
//     i++;
// }



// Another Multiplication table in while loop
// let no = parseInt(prompt('enter any integer value'))
// let range = parseInt(prompt('enter range of table'))
// let i = 1;
// while (i<=range) {
//     result = i*no;
//     console.log(`${no} * ${i} = ${result}`);
//     i++;
// }



// Another Multiplication table in while loop with Confirm Statement
// let no = parseInt(prompt('enter any integer number'))
// let range = parseInt(prompt('enter the range of TB'))
// let conf = confirm("are you sure to see the Table?");
// if(conf == true){
//     let i=1;
//     while (i<=range) {
//         result = i*no;
//         console.log(`${no} * ${i} = ${result}`)
//         i++;
//     }
// }



// Functions in JS 

// function greet(name, city) {
//     console.log(`welcome Mr. ${name} in our Mango city ${city}`)
// }
// let city = "Mirpurkhas"; 
// greet("Natesh Kumar", city)
// greet("Natu Kumar", city)
// greet("Avinash Kumar", city)
// greet("Akshay Kumar", city)
// greet("Snjay Kumar", "Hyderabad")



let = greet212121 = (namee212121, city212121) =>{
    console.log(`welcome Mr. ${namee212121} in our beautiful ${city212121} city.`)
}
let city212121 = "Mirpurkhas";
greet212121("Natu", city212121);
greet212121("Nitu", city212121);
greet212121("Nitesh", city212121);
greet212121("Niku", city212121);
greet212121("Niteshwar", "Hyderabad");
greet212121("Deepu", "Karachi");



// For Each Function 
// let names = ["Natesh", "Pikazu", "Piru", "Kashu"];
// names.forEach(function (bhailog) {
//     console.log(`Welcome in Our resort ${bhailog}`)
// })




// Again Table 
// let num = parseInt(prompt('enter any integer number?', 'enter here..'));
// let range = parseInt(prompt('enter the range of table'));
// let namee = prompt("what's your name?");
// let conf = confirm('are you want to see table?');
// if( conf == true ){
//     console.log(`Mr. ${namee} the Table of ${num} is here:`);
//     let i;
//     for(i=1; i<=range; i++){
//     result = i*num;
//     console.log(`${num} * ${i} = ${result}`)
//     }
// }
// else{
//     console.log(`Mr ${namee} Better luck for next time`)
// }





// let range = parseInt(prompt('how many times prompt should run?'));
// for (let i=1; i<=range; i++) {
//     let data = prompt('enter your name');
//     let conf = confirm('do u wanna save this name?')
//     if (conf == true) {
//         data = JSON.stringify(data);
//         console.log(data)
//     }
//     else{
//         console.log("you did not save name")
//     }
    
// }
// yeh user se pouchega k kitni baar prompt chale or agay condition bhi pouchega 
// k num save kre ya nhi agar han toh console mei show hoga 




// let range21 = parseInt(prompt("how many times prompt should run Sir..?"));
// for (let i=1; i<=range21; i++){
//     let name212121 = prompt("enter your name");
//     let data212121 = confirm("do u wanna save this name");
//     if(data212121 == true){
//         name212121 = JSON.stringify(name212121);
//         console.log(name212121)
//     }
//     else {
//         console.log("sir you did'nt save name")
//     }
// }




// Functions and Event Listener on any HTML element:

// Event Listener:
// let btn = document.getElementById('btn');
// btn.addEventListener('click', function() {
//     let head = document.getElementById('head');
//     head.style.color = "White";
//     head.style.backgroundColor = "Black" 
// })
// btn.addEventListener('dblclick', function () {

//     head.style = 'none';
// })
// Single Click krengy toh head ka color or backgroundColor change hoajayega 
// or jese hi Double click krengy head same phle jesa defaulted hojayega




// Onclick Function:
// function colorChange() {
//     let head1 = document.getElementById('head1');
//     head1.style.backgroundColor = "red";
//     head1.style.color = "white";
//     head1.style.fontSize = "42px";

// }
// function def() {
//     head1.style = 'none';
// }
// jese hi click krengy h2 ka color, bgcolor, fontSize sab chnge hojayega
// or jese hi double click krengy h2 same defaulted hojayega  




// Arrow Functions 
// let date = (name) => {
//     console.log(`Welcome in Kukuduu ku Restaurant, ${name}`)
// }
// date("Natesh");
// date("Pikazu");
// date("Kashu");
// date("Kashi");
// date("Pihualla");
// date("Hula balu");




let restDate = (namee213) =>{
    console.log(`welcome in kukudu Resort ${namee213}`)
}
restDate("Nitu")
restDate("Pihu")
restDate("Kashu")
restDate("Munu")




// simple one argument task 
// let calc = (a) => console.log(a + 2);
// calc(2);
// calc(4);
// calc(6);
// calc(7);
// it will show the results and it is shortage of function 



// Simple one argument task with prompt 
// let calc = (a) => console.log(a + 1);
// let a = parseInt(prompt('enter any integer number'))
// calc(a);



// let a = parseInt(prompt('enter ant integer number?'))
// let calc = (a) => console.log(a + 3);
// calc(a)



// Arrow func in setTimeout 
// setTimeout(() => { console.log(`Hello Mr. Natesh Kumar`)
    
// }, 3000,);



// Arrow func in setInterval
// setInterval(() => {
//     console.log(`Mr. Natesh kumar welcome`)
// }, 2000);



// Arrow func in setInterval
// let greet = (name) => {
//     console.log(`Good Morning, ${name}, have a nice day..!`)
// }
// setInterval(greet, 4000, "Natesh"); 



// Arrow func in setTimeout
// let greet = (name) => console.log(`Good Morning, ${name}, have a nice day..!`)
// setTimeout(greet, 3000, "Natu")



// let greeting21 =  (namee2121) =>{
//     namee2121 = prompt("enter your nameeee");
//     console.log(`Good Night Mr. ${namee2121} Kumar, have a sweet dreams..!`)
// }
// setTimeout(greeting21, 1000, "Natesh");



let greeting21 = (namee2121) =>{
    console.log(`Good night, ${namee2121}`)
}
setTimeout(greeting21, 1000, "Nitesh");



// setTimeout func 
// function greet(name, age, address) {
//     console.log(`good morning, Mr. ${name}, ur age is ${age} and ur home address is ${address} `)
// } 
// setTimeout(greet, 3000, "Natesh", 20, "h#75 Karimabad town Mpk" )



// setInterval func 
// function greet(name, age, postal, mob, address) {
// console.log(`Mr. ${name} ur age is ${age} and ur postal code is ${postal} & ur mobile number is ${mob} and ur address is ${address}`)    
// }
// setInterval(greet, 4000, "Natesh kumar", 20, 6900, 03065444146, "H#75 Karimabad town");



// set timeout with clear timeout 
// function hello(name) {
//     console.log(`hello ${name}, in our resort.`)
// }
// clear = setTimeout(hello, 3000, "Natu");
// console.log(clear);
// clearTimeout(clear)



// set timeout with clear interval 
// function hello(name) {
//     console.log(`hello ${name}, in our restaurant`)
// }
// clear = setInterval(hello, 2000, "Natesh")
// console.log(clear)
// clearInterval(clear)



// Set Interval 
// function clk() {
//     let time = new Date();
//     console.log(time)
// }
// setInterval(clk, 1000)
// yeh time show krega baar baar



// let clk = () =>{
//     let newDate = new Date();
//     console.log(newDate)
// }
// setInterval(clk, 1000);
// har sec mei time show hoga 



// Array with array func toLowerCase 
// let namee = prompt('enter your name?', 'enter here...')
// namee = namee.toLowerCase();
// let names = ['natesh', 'natu', 'pihu', 'kashu' ];
// if(namee == names[0]){
//     alert(`Welcome Paglu Natesh`)
// } 
// else if(namee == names[1]){
//     alert(`Welcome Paglu Natu`)
// } 
// else if(namee == names[2]){
//     alert(`Welcome Paglu Pihu`)
// } 
// else if(namee == names[3]){
//     alert(`Welcome Paglu Kashu`)
// } 
// else{
//     alert('u r unknown')
// }
// yeh jesa bhi prompt mei dalengy yeh usko LowerCase mei krdehga 




let name211 = prompt("enter your name Sir ji?", "enter here...");
let arr = ["Natesh", "Natu", "Niku", "Nitu"];
if(name211 == arr[0]){
    alert("welcome Mr. " + arr[0])
}
else if(name211 == arr[1]){
    alert("welcome Mr. natu ji ")
}
else if(name211 == arr[2]){
    alert("welcome Mr. niku ji ")
}
else if(name211 == arr[3]){
    alert("welcome Mr. nitu ji ")
}
else{
    alert("unknown")
}


let namee = prompt("enter your name Sir?", "enter here..");
namee = namee.toLowerCase();
if(namee == "Natu"){
    alert("welcome  Natu.!!")
}
else if(namee == "nitu"){
    alert("welcome  Nitu.!!")
}
else if(namee == "natesh"){
    alert("welcome  Natesh.!!")
}
else if(namee == "niku"){
    alert("welcome  Niku.!!")
}
else if(namee == "natu"){
    alert("welcome  Natu.!!")
}
else{
    alert("it's not me")
}


// Simple calculator 
let a = parseInt(prompt('enter the operand 1'))
let op = prompt('enter the operator');
let b = parseInt(prompt('enter the operand 2'))
if (op == '+') {
    let res = a+b;
    console.log(`the addition of a & b = ${res}`)
}
else if (op == '-') {
    let res = a-b;
    console.log(`the subtraction of a & b = ${res}`)
}
else if (op == '*') {
    let res = a*b;
    console.log(`the multiplication of a & b = ${res}`)
}
else if (op == '/') {
    let res = a/b;
    console.log(`the division of a & b = ${res}`)
}
else if (op == '%') {
    let res = a%b;
    console.log(`the modulus of a & b = ${res}`)
}
else{
    console.log(`it can't calc`)
}




// Simple table with range
// let num = parseInt(prompt('enter the num of table'));
// let range = parseInt(prompt('enter the range of table'))
// let i;
// for(i=1; i<=range; i++){
//     res = num*i;
//     console.log(`${num} * ${i} = ${res}`)
// }



// Simple table 
// let no = parseInt(prompt('enter any integer'))
// for(let i=1; i<=10; i++){
//     res = no*i;
//     console.log(`${no} * ${i} = ${res}`)
// }


// Simple table in another form with limit
let no = parseInt(prompt("enter any integer ;;;;;"));
let noLength = parseInt(prompt("enter limit ;;;;;;"));
var i;
for ( i=1; i<=noLength; i++){
let res = no*i;
console.log(`${no} * ${i} = ${res}`);
}



// Date Format 
// Date(year, month, date, hour, minute, second, mili second ) i.e: month always start from 0 to 11 
let date = new Date('2000', '05', '15', '7', '40', '20', '43')
let tc = document.getElementById('tx').innerHTML = (`Mr. Natesh your Birth was ${date}`)
// console.log(date)


let dy = date.getDay();
console.log(`the day is ${dy}`)
let yr = date.getFullYear();
console.log(`the Year is ${yr}`)
let mnth = date.getMonth();
console.log(`the Month is ${mnth}`)
let dat = date.getDate();
console.log(`the Month is ${dat}`)
let hr = date.getHours();
console.log(`the Hour is ${hr}`)
let mint = date.getMinutes();
console.log(`the Minutes are ${mint}`)
let sec = date.getSeconds();
console.log(`the Seconds are ${sec}`)
let msec = date.getMilliseconds;
console.log(`the MiliSeconds are ${msec}`)



// JSON which convert objejct into string 
let obj = {
    name: "Natu",
    age: 20,
    post: 69000,
    add: "H#75 karimababd town mpk"
}
let ob = JSON.stringify(obj)
console.log(ob)
// yeh isko string mei convert krdehga


// ab upar wale string par kch methods laga kar hum string ko modify krengy
let obj1 = ob.replace('Natu','Natesh Kumar')
console.log(obj1)


// Another method 
// obj1 = obj1.charAt(9)
// console.log(obj1)
// 9th p konsa element hai string ka 

let obj12 = obj1.slice(9, 21)
obj12 = obj12.toUpperCase();
console.log(obj12)
// yeh Natesh ko pakar kar slice method se usko toUpperCase mei krdehga

console.log(obj1)

// JSON which convert string into objejct
let obj11 = JSON.parse(obj1);
console.log(obj11)
// yeh us String ko Dubara Object mei krdehga












// the random number between 1 & 100 
function rand() {
    let a = 1;
    let b = 100;
    let rand = a*(b-a)*Math.random();
    let dt = document.getElementById('dt1').innerHTML = (`the random number b/w 1 & 100 = ${rand} <br>`)  
}
setInterval(rand, 1000)




// CLock on set setInterval 
function clock() {
    time = new Date();
    let date = document.getElementById('dt').innerHTML = time
}
setInterval(clock, 1000)



























// random b/w 1 & 10
// function randommm() {
//     let a = 1;
//     let b = 10;
//     let randomm = a*(b-a)*Math.random();
//     console.log(randomm)
// }
// setInterval(randommm, 1000)


// clock 
// function clk() {
//     dtt = new Date();
//     document.getElementById('dttt').innerHTML = dtt;
// }
// setInterval(clk, 1000)


// calendar 
// let datee = new Date(2015, 08, 6, 07, 54, 44, 46)
// console.log(datee)


// arrays
// let names = ["Natu", "Natesh"];
// console.log(names)


// Objects
// let objjj = {name: "Natu", age: 20, address: "house #75 Karimabad Town", city: "Mirpurkhas"};
// console.log(objjj)


// For Loop 
// for(var i=0; i<=10; i++){
//     console.log(i)
// }

// while loop
// let i=0;
// while (i<=10) {
//     console.log(i);
//     i++;
// }


// Do while loop 
// let i=0;
// do {
//     console.log(i);
//     i++;
// } while (i<=9);


// table in for loop
// let i ;
// let num = parseInt(prompt('enter any integer'));
// let l = parseInt(prompt('enter the limit'));
// for(i=1; i<=l; i++){
//     result = i*num;
//     console.log(`${num} * ${i} = ${result}`)
// }


// simple table
// let num = parseInt(prompt('enter any integer'));
// for(let i=1; i<=10; i++){
//     result = num*i;
//     console.log(`${num} * ${i} = ${result}`)
// }


// for each loop for array
// let arr = ["Natu", "Natesh", "Pihu", "Pikazu"];
// arr.forEach(function (bhai) {
//     console.log(`${bhai} welcome in our resort `)
// })


// for of loop for array 
// let arr = ["Natu", "Natesh", "Natuzu"];
// for (const name of arr) {
//     console.log(`welcome Mr. ${name}`)
// }


// for in loop for objects
// let obje = {name: "'Natesh'", age: 20, address: "'H#75 karimabad'", city: "'MPK'", Postal: 69000}
// for (const key in obje) {
//         console.log(`the ${key} of this object is ${obje[key]}`)
// }



// let dateee = new Date(2019, 09, 17, 6, 45, 54, 44); 
// console.log(dateee)
// let yrrr = dateee.getFullYear();
// console.log(yrrr)
// let mn1 = dateee.getMonth();
// console.log(mn1)
// let dt1 = dateee.getDate();
// console.log(dt1)
// let hr1 = dateee.getHours();
// console.log(hr1)
// let min1 = dateee.getMinutes();
// console.log(min1)
// let sec1 = dateee.getSeconds();
// console.log(sec1)
// let msec1 = dateee.getMilliseconds();
// console.log(msec1)



// set timeout func
// function hello() {
//     let namess = ["natu", "Natuzu", "Niku"]
//     namess.forEach((element) => {
//         console.log(`welcome Mr. ${element}`)
//     });  
// } 
// setTimeout(hello, 2000);



// set interval func 
// function hell() {
//     let obje2 = {name: "ahmad", age: 22, add: "Mustafa Town"}
//     for (const key in obje2) { 
//         console.log(`the ${key} of this object is ${obje2[key]}`)
//       }
// }
// setInterval(hell, 3000);


// Json Object to string 
let ahmadBio = {name: "Ahmad Khalil", age: 22, addr: "mustafa town", city: "mpk"};
console.log(ahmadBio); // it is object //
let strrr = JSON.stringify(ahmadBio);
console.log(strrr) // it has been converted into string //

strrr1 = strrr.repeat(2);
console.log(strrr1)// here we are modify the string //

strrr2 = strrr.replace("Ahmad", "Ahad")
console.log(strrr2) // it will replace ahmad to ahad //

let strobj = JSON.parse(strrr2);
console.log(strobj) // it will convert string into object again //



// SetTimeout Func with something new
function hel(name, age, addr, song) {
    console.log(`hello Mr. ${name} ur age is ${age} and ur home address is ${addr} & we know tha t ur fav song is ${song}`)
}
setTimeout(hel, 2000, "Natesh Kumar", 20, "H#75 Karimabad Town", "'Dil Chahte ho ya Jaan Chahte ho'");


// set timeout func with more addition 
setTimeout((nameee, resort, five) => {
    console.log(`hello Mr. ${nameee}, welcome in our resort ${resort} have a nice day in this ${five}`)
}, 3000, "Natu", "'Pearl Continental'" , "'5-star hotel'");


// we can set these same in setInterval function 
setInterval((nameeee) => {
    console.log(`hello bhai ${nameeee} kese ho ?`)
}, 4000, "Natesh");

function hell2(name, age, city) {
    console.log(`hello ${name}, u r ${age} years-old. and ur city is ${city}`)
}
setInterval(hell2, 6000, "Natu", 20, "Mirpur");



// for loop 
// let namee21 = prompt('enter your name');
// let i;
// for(i=0; i<=1; i++){
//     alert(`hello Mr. ${namee21}`)
// }
// ismei hum condition iteration or increment sab 1 sath dehte hai or yeh sab 1 baar check krke phir hi agay proceed krta hai 


// while loop
// let na = prompt('enter your name?')
// let i=0; 
// while (i<1) {
//     alert(`u r too late sir ${na}`)
//     i++;
// }
// ismie yeh phle condition check krega k worng hao ya right phir hi execute krega warna rok dehga 


// Do while loop 
// let i = 0;
// do {
//     alert(`hello bhai`)
//     i++;
// } while (i<=0);
// ismei condition baad mei check hoti hai agar wrong hogi toh at least 1 baar chalega jese ismei hai 



function clickMe() {
    let name = prompt("enter your name");
    alert(`Welcome mere ${name} bhai.!`)
}
// yeh func hai jismei aap waha click krogw toh uske baad show hoga 